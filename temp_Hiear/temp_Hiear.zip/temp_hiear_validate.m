%do nothing now
function pars=temp_hiear_validate(pars)