%do nothing now
function pars=temp_hiear_predict(pars)