function pars = pars_initial(method)

pars    = struct();

if strcmp(method, 'hiear')==1
%% Parameters for hiear (two layers) method
    pars.method     = 'hiear';
    pars.data       = 'toy_data'; 
    pars.valid_size = 0.1;
    tmp_clock       = clock;
    pars.save       = ['toy_result_' int2str(tmp_clock(1)) int2str(tmp_clock(2)) int2str(tmp_clock(3)) 'T' int2str(tmp_clock(4)) int2str(tmp_clock(5))];
    %the input data should contain at least three arrays:
    %   frame1_images:   [data_length, input_size*input_size]
    %   frame2_images:   [data_length, output_size*output_size]
    %   frame3_images:   [data_length, output_size*output_size]
    
    %layer1 is for learning the transformations of two images
    pars.layer1_numfactors         = 200;
    pars.layer1_batchsize          = 100;
    pars.layer1_batchOrderFixed    = true;
    pars.layer1_nummap             = 100;
    pars.layer1_save               = ['toy_layer1_' int2str(tmp_clock(1)) int2str(tmp_clock(2)) int2str(tmp_clock(3)) 'T' int2str(tmp_clock(4)) int2str(tmp_clock(5))];
    %layer1_save file should contain:
    %   layer1_13_pars:     pars for 13 transformations
    %   layer1_12_pars:     pars for 12 transformations
    
    %layer2 is for learning the transformations of transformations
    pars.layer2_numfactors         = 200;
    pars.layer2_batchsize          = 100;
    pars.layer2_batchOrderFixed    = true;
    pars.layer2_nummap             = 100;
    pars.layer2_save               = ['toy_layer2_' int2str(tmp_clock(1)) int2str(tmp_clock(2)) int2str(tmp_clock(3)) 'T' int2str(tmp_clock(4)) int2str(tmp_clock(5))];
    %layer2_save file should contain:
    %   layer2_pars:    pars for transformations of transformations
end